from setuptools import setup

setup(
    name = 'VIGA_PREPRO',
    version = '0.0.0',
    author = 'Prof. Wanderlei M. Pereira Junior, Engenheiro Civil Gustavo Gonçalves Costa, Engenheiro Civil Matheus Henrique Morato de Moraes',
    author_email = 'wanderlei_junior@ufcat.edu.br',
    url='https://wmpjrufg.github.io/VIGA-PREPRO/',
    packages = ['VIGA_PREPRO']
)